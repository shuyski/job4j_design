package ru.job4j.oop;

public interface Vehicle {
    void move();

    void speed();
}
