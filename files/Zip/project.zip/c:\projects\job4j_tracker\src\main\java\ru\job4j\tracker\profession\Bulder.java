package ru.job4j.tracker.profession;

public class Bulder extends Engineer {

    private int date; // количество дней до сдачи объекта

    public int getDate() {
        return date;
    }
}
