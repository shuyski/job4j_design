package ru.job4j.tracker.profession;

public class Dentist extends Doctor {

    private int koltooth; // количество выдернутых зубов в день
    private String namemed; // название стоматологической клиники

    public int getKoltooth() {
        return koltooth;
    }

    public String getNamemed() {
        return namemed;
    }

}


