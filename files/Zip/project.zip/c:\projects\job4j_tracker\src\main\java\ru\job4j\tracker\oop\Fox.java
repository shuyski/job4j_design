package ru.job4j.tracker.oop;

public class Fox {
    public void tryEat(Ball ball) {

}

}
