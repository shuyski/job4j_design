package ru.job4j.tracker.oop;

public class Fix {
    public static void main(String[] args) {
        Fix item = new Fix();
    }
}
