package ru.job4j.tracker.profession;

public class Surgeon extends Doctor {

    private int numoperoflang; // количество операций на лёкгие в месяц
    private int numoperofheart; // количество операций на сердце в месяц

    public int getNumoperoflang() {
        return numoperoflang;
    }

    public int getNumoperofheart() {
        return numoperofheart;
    }
}


