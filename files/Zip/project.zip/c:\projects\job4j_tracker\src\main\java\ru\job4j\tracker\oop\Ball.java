package ru.job4j.tracker.oop;

public class Ball {
    public void tryEat(Ball ball) {

    }
}
