package ru.job4j.poly;

public interface Transport {

    void go();

    void count(int passen);

    int price(int fuel);
}
