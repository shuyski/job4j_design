package ru.job4j.ex;

public class UserInvalidException extends Exception {
    public UserInvalidException(String message) {
        super(message);
    }
}
