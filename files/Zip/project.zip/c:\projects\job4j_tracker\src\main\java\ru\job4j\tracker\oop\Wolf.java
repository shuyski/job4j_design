package ru.job4j.tracker.oop;

public class Wolf {
    public void tryEat(Ball ball) {

    }
}
