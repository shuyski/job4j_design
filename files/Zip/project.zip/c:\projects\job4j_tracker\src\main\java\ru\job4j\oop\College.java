package ru.job4j.oop;

public class College {
    public static void main(String[] args) {
        Freshman man = new Freshman();
        Student student = man;
        Object object = man;

        System.out.println(new Freshman());
    }
}
