package ru.job4j.tracker.oop;

public class Hare {
    public void tryEat(Ball ball) {

}

}
